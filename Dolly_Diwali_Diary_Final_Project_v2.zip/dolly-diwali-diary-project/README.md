# Dolly's Diwali Diary

A private, offline-first order ledger for Dolly's Diwali snack business. This is not a customer ordering app.

## Features
- Classic cream, maroon and gold mobile UI with Dolly's supplied logo
- Add orders without asking for a customer phone number
- Karanji starts at ₹150 per packet
- Multiple products per bill, quantities, automatic totals, unique bill numbers
- Paid/unpaid status and ability to mark an old unpaid bill as paid
- Searchable order history and individual bill view/edit/delete
- Individual PDF and combined PDF exports, CSV export, JSON backup/restore
- Product catalogue with sell price and cost per unit; products can be edited or deleted from the catalogue; old bill prices are snapshots
- New bills display today’s date automatically in Asia/Kolkata; the date picker stays hidden unless Dolly taps “Change date” for a backdated bill
- Expense tracking and estimated profit (sales minus item costs minus recorded expenses)
- Browser localStorage persistence and service-worker caching for hosted use
- Android WebView project and GitHub Actions workflow to build a debug APK

## Important data note
Orders are stored locally on the device (browser/app storage), not in cloud sync. Download a JSON backup regularly and keep it somewhere safe. Clearing app/browser data can erase unbacked-up records. The profit figure is only as accurate as the per-unit costs and expenses entered.

## Latest final updates
The order form now shows the current India date as a simple summary instead of opening the calendar on every new bill. A separate “Change date” action reveals the calendar only when needed. Manage Products now has a visible Delete button with a confirmation step; deleting a product removes it only from the catalogue, not from previously saved bills.

## Mobile layout revision
The bottom navigation is deliberately compact and equal-height: the Add Order control is not a floating/oversized button. The page reserves 112px plus safe-area space below content so form actions and the last bill rows can scroll above the navigation.

## Quick source checks
Run `node tests/smoke.test.cjs` from the project root. It checks zero-state rendering, saving a customer order at the Karanji rate, marking an unpaid order paid, editing a bill while retaining its bill number, and PDF/CSV export paths. This is a scripted smoke test, not a full Android device test.

## Test in a browser
Open `www/index.html` through a local static web server or host the `www` directory. The app is designed for a portrait Android screen. The logo is at `www/assets/dolly-logo.png`.

## Build the Android APK
The Android project is in `android/`. `.github/workflows/build-apk.yml` builds `android/app/build/outputs/apk/debug/app-debug.apk` on GitHub Actions. Put this project in a GitHub repository, push it to `main`, then open **Actions → Build Dolly's Diwali Diary APK** and download the `dolly-diwali-diary-debug-apk` artifact. This workflow is supplied but has not been run in this environment, so the APK still needs a CI build verification.

The APK runs the bundled app from Android assets, stores its data in the app's WebView local storage, and saves PDF/CSV/JSON downloads under `Downloads/Dolly Diwali Diary` using Android's download storage.
