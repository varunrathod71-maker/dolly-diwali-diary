const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const html = fs.readFileSync(path.join(__dirname, '../www/index.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];
assert(html.includes("timeZone:'Asia/Kolkata'"), 'new order dates must use India local date');
assert(html.includes('Today · added automatically') && html.includes('data-action="change-order-date"'), 'order form should show the auto-filled date and allow optional date changes');
assert(html.includes('data-action="delete-product"'), 'product catalogue should expose a delete action');
assert(html.includes("date:localDate()"), 'new orders should default to today');
let toast = null;
const downloads = [];
const fakeURL = { createObjectURL(blob) { downloads.push(blob); return 'blob:smoke-test'; }, revokeObjectURL() {} };
const main = { innerHTML: '' };
const modal = { innerHTML: '' };
const restore = { click() {}, addEventListener() {} };
const listeners = {};
const store = {};
const fields = {
  '#customer': { value: '' },
  '[data-field="customer"]': { value: '' },
  '[data-field="date"]': { value: '2026-10-24' },
  '[data-field="notes"]': { value: '' },
  'input[name="paid"]:checked': { value: 'no' },
};
let currentQty = { value: '1' };
const navButtons = ['home', 'orders', 'new', 'more'].map(page => ({ dataset: { page }, classList: { toggle() {} } }));
const document = {
  querySelector(selector) {
    if (selector === '#main') return main;
    if (selector === '#restoreFile') return restore;
    if (selector === '#modalRoot') return modal;
    if (selector === '#toast') return toast;
    return fields[selector] || null;
  },
  querySelectorAll(selector) {
    if (selector === '.nav-btn') return navButtons;
    if (selector === '[data-item-row]') return [{ dataset: { itemRow: '0' }, querySelector(sel) { return sel.includes('qty') ? currentQty : null; } }];
    return [];
  },
  addEventListener(type, cb) { (listeners[type] ||= []).push(cb); },
  createElement() {
    return { style: {}, classList: { add() {}, remove() {} }, append() {}, remove() {}, click() {}, setAttribute() {} };
  },
  body: { append(el) { if (el.id === 'toast') toast = el; } },
};
const localStorage = { getItem(key) { return store[key] || null; }, setItem(key, value) { store[key] = value; } };
const context = {
  document, localStorage, window: { scrollTo() {} }, navigator: {}, console, Blob, FileReader: class {}, URL: fakeURL,
  Date, Math, JSON, Number, String, Array, Object, Promise, Set, Map, RegExp, Error,
  confirm: () => true, setTimeout: () => 1, clearTimeout() {},
};
vm.runInNewContext(js, context, { timeout: 3000 });
const click = (dataset) => listeners.click[0]({ target: { closest: () => ({ dataset }) }, preventDefault() {} });
const submit = (id) => listeners.submit[0]({ target: { id, dataset: {} }, preventDefault() {} });

assert(main.innerHTML.includes('Total sales'));
assert(main.innerHTML.includes('₹0'));
assert(main.innerHTML.includes('No orders yet'));
assert(main.innerHTML.includes('Karanji is already added at ₹150 per packet'));

click({ page: 'new' });
assert(main.innerHTML.includes('Customer name *'));
assert(main.innerHTML.includes('Add another item'));
assert(main.innerHTML.includes('Save Order'));
assert(!main.innerHTML.includes('Phone Number'));
fields['#customer'].value = 'Test Customer';
fields['[data-field="customer"]'].value = 'Test Customer';
fields['[data-field="date"]'].value = '2026-10-24';
fields['[data-field="notes"]'].value = '';
fields['input[name="paid"]:checked'].value = 'no';
currentQty.value = '3';
submit('orderForm');
let saved = JSON.parse(store['dollys-diwali-diary-v1']);
assert.strictEqual(saved.orders.length, 1);
assert.strictEqual(saved.orders[0].billNo, 'DD-2026-0001');
assert.strictEqual(saved.orders[0].items[0].price, 150);
assert.strictEqual(saved.orders[0].items[0].qty, 3);
assert.strictEqual(saved.orders[0].items[0].price * saved.orders[0].items[0].qty, 450);
assert.strictEqual(saved.orders[0].paid, false);

click({ action: 'toggle-paid', id: saved.orders[0].id });
saved = JSON.parse(store['dollys-diwali-diary-v1']);
assert.strictEqual(saved.orders[0].paid, true, 'existing unpaid bill can be marked paid');

click({ action: 'edit-order', id: saved.orders[0].id });
fields['#customer'].value = 'Updated Customer';
fields['[data-field="customer"]'].value = 'Updated Customer';
fields['input[name="paid"]:checked'].value = 'yes';
currentQty.value = '2';
submit('orderForm');
saved = JSON.parse(store['dollys-diwali-diary-v1']);
assert.strictEqual(saved.orders[0].billNo, 'DD-2026-0001', 'editing preserves bill number');
assert.strictEqual(saved.orders[0].customer, 'Updated Customer');
assert.strictEqual(saved.orders[0].items[0].qty, 2);
assert.strictEqual(saved.orders[0].items[0].price * saved.orders[0].items[0].qty, 300);

click({ page: 'products' });
assert(main.innerHTML.includes('e.g. Chuwada / Chakli'));
click({ page: 'bills' });
assert(main.innerHTML.includes('Download all bills (PDF)'));
assert(main.innerHTML.includes('Export CSV'));
click({ action: 'export-all' });
click({ action: 'export-csv' });
(async () => {
  assert.strictEqual(downloads.length, 2, 'PDF and CSV download paths were called');
  const pdfText = await downloads[0].text();
  assert(pdfText.startsWith('%PDF-1.4'), 'PDF export has a PDF header');
  assert(pdfText.includes('DD-2026-0001'));
  assert(pdfText.includes('Updated Customer'));
  const csvText = await downloads[1].text();
  assert(csvText.includes('DD-2026-0001'));
  assert(csvText.includes('Updated Customer'));
  console.log('PASS: zero-data dashboard, add order, automatic total, unpaid→paid, edit bill without changing bill number, product screen, all-bill PDF structure and CSV export.');
})().catch(err => { console.error(err); process.exitCode = 1; });

// Final mobile UI regressions: no phone-number field and no oversized/floating Add Order button.
const orderFormSource = (html.match(/function newOrderPage\(\)[\s\S]*?function /) || [''])[0];
assert(!/<input[^>]*(?:type=[\"']tel|name=[\"'][^\"']*phone|id=[\"'][^\"']*phone)/i.test(orderFormSource), 'Order form must not contain a phone/customer-number input');
assert(html.includes('padding-bottom:calc(112px + var(--safe-bottom))'), 'Reserve enough bottom space so content does not hide behind navigation');
assert(html.includes('min-height:54px;align-self:center;justify-self:stretch;max-width:100%'), 'Add Order navigation button must stay compact and inside the navigation');
console.log('PASS: compact bottom navigation and safe content spacing.');
